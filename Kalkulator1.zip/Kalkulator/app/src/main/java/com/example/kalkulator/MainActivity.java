package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;
public class MainActivity extends AppCompatActivity {
//ID SEMUA  TOMBOL NUMERIC
    private int[] tombolNumeric = {R.id.tombolnol, R.id.tombolsatu,
            R.id.tomboldua, R.id.tomboltiga, R.id.tombolempat,
            R.id.tombollima, R.id.tombolenam, R.id.tomboltujuh,
            R.id.tomboldelapan,
            R.id.tombolsembilan};
//ID SEMUA TOMBOL OPERATOR
    private int[] tombolOperator = {R.id.tombolKali, R.id.tombolBagi, R.id.tombolTambah, R.id.tombolKurang};
//TEXT DIGUNAKAN UNTUK MENAMPILKAN OUTPUT
    private TextView LayarTampil;
    //MENYATAKAN APAKAH TOMBOL TERAKHIR DITEKAN BERSIFAT NUMERIC ATAU TIDAK
    private boolean angkaTerakhir;
    //MENYATAKAN BAHWA KEADAAN  SAAT INI SEDANG ERROR  ATAU TIDAK
    private boolean kaloError;
    //JIKA BENAR JANGAN IZINKAN MENAMBAHKAN DOT LAIN
    private boolean setelahTitik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //TEMUKAN TEXT VIEW
        this.LayarTampil = (TextView) findViewById(R.id.LayarTampil);
        //TEMUKAN DAN ATUR ON CLIK LISTENER KE TOMBOL NUMERIK
        setNumericPadaSaatDiKlik();
        //TEMUKAN DAN ATUR ONCLIKLISTENER KE TOMBOL OPERATOR TOMBOL SAMA DENGAN DAN TOMBOL TITIK DESIMAL
        setOperatorPadaSaatDiKlik();
    }

    private void setNumericPadaSaatDiKlik() {
        //BUAT ONCLICKLISTENER
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        //CUKUP TAMBAHKAN ATUR TEKS TOMBOL YANG DI KLIK
                Button tombol = (Button) v;
                if (kaloError) {
                    LayarTampil.setText(tombol.getText());
                    kaloError = false;
                } else {
                    LayarTampil.append(tombol.getText());
                }
                angkaTerakhir = true;
            }
        };
        for (int id : tombolNumeric) {
            findViewById(id).setOnClickListener(listener);
        }
    }

    private void setOperatorPadaSaatDiKlik() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (angkaTerakhir && !kaloError) {
                    Button tombol = (Button) v;
                    LayarTampil.append(tombol.getText());
                    angkaTerakhir = false;
                    setelahTitik = false;
                }
            }
        };
        for (int id : tombolOperator) {
            findViewById(id).setOnClickListener(listener);
        }
        findViewById(R.id.tombolkoma).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (angkaTerakhir && !kaloError && !setelahTitik) {
                    LayarTampil.append(".");
                    angkaTerakhir = false;
                    setelahTitik = true;
                }
            }
        });
        findViewById(R.id.tombolC).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayarTampil.setText(" ");
                angkaTerakhir = false;
                kaloError = false;
                setelahTitik = false;
            }
        });
        findViewById(R.id.hasil).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onEqual();
            }

            private void onEqual() {
                if (angkaTerakhir && !kaloError) {
                    String txt = LayarTampil.getText().toString();
                    Expression expression = new ExpressionBuilder(txt).build();
                    try {
                        double result = expression.evaluate();
                        LayarTampil.setText(Double.toString(result));
                        setelahTitik = true;
                    } catch (ArithmeticException ex) {
                        LayarTampil.setText("ERROR REN");
                        kaloError = true;
                        angkaTerakhir = false;
                    }
                }
            }
        });
    }
}